<div class="clr"></div>
</div>
<div class="clr"></div>
</div>
<div class="footer">
<center>
<div style="margin:2px; opacity:0.2">
</div>
</center>
<div class="clr-line"></div>
</div>
</div>
</body>
</html>
